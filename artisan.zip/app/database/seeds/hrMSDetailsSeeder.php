<?php
class hrMSDetailsSeeder extends Seeder {
    public function run()
    {


    }
}