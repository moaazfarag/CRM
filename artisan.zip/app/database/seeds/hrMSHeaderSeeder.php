<?php
class hrMSHeaderSeeder extends Seeder {
    public function run()
    {

    }
}
