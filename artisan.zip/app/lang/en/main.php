<?php
return array(

    'password' => 'كلمة المرور',

);