@include('include.header')
@include('include.aside')
@include('include.breadcrumb')
    @yield('content')
@include('include.search')
@include('include.footer')





