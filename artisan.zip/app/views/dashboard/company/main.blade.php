@include('include.header_add_company')
@yield('content')
@include('include.footer')