@extends('dashboard.main')
@section('content')
        <!-- Main Content -->
<section id="print-content"  ng-app="itemApp"  ng-controller="mainController" class="content-wrap ecommerce-invoice">

<div class="container">

    <img src="{{URL::asset('dashboard/img/404.png')}}" width="80%" style="width: 70%; min-height: 400px;"  />
    <h1>
        الصفحة المطلوبة غير موجودة 
    </h1>
</div>

</section>
<!-- /Main Content -->
@stop