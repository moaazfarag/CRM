 <?php
/**
 * Created by PhpStorm.
 * User: ahmed
 * Date: 9/8/2015
 * Time: 2:02 PM
 */
 class ReturnsInvoice extends Eloquent
 {

     protected $table = 'trans_header';
     public static $store_rules = array(

     );
 }